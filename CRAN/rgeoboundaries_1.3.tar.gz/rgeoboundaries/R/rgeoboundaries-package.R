##' rgeoboundaries
##'
##' R client to access geoBoundaries API
##'
##' @name rgeoboundaries-package
##' @aliases rgeoboundaries
##' @docType package
##' @author \email{mail@ahmadoudicko.com}
##' @keywords package
NULL
